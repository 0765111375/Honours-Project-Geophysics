"""Common paths, fold labels, model construction and evaluation."""
from pathlib import Path
import os,json,hashlib,platform,importlib.metadata,warnings
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import (accuracy_score,precision_score,recall_score,f1_score,roc_auc_score,
 average_precision_score,balanced_accuracy_score,matthews_corrcoef,confusion_matrix,
 ConfusionMatrixDisplay,RocCurveDisplay,PrecisionRecallDisplay)
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.linear_model import LogisticRegression
from threadpoolctl import threadpool_limits
import joblib
_THREAD_LIMIT=threadpool_limits(limits=1)
ROOT=Path(__file__).resolve().parent.parent
DATA_DIR=next((ROOT/n for n in ['data','Data'] if (ROOT/n/'raw/Moabevpall.txt').exists()),None)
if DATA_DIR is None:raise FileNotFoundError('Put Data/raw/Moabevpall.txt beside the notebooks folder (lowercase data also works).')
PROCESSED_DIR=DATA_DIR/'processed_final';RESULTS_DIR=ROOT/'results_final'
for p in [PROCESSED_DIR,RESULTS_DIR]:p.mkdir(parents=True,exist_ok=True)
SEED=42

def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()

def environment():
 names=['numpy','pandas','scipy','scikit-learn','xgboost','matplotlib','seaborn','statsmodels','joblib','nbformat','ipython','ipykernel','threadpoolctl']
 return {'python':platform.python_version(),'platform':platform.platform(),'packages':{n:importlib.metadata.version(n) for n in names},'seed':42,'threads':1}

def load_features():
 train=pd.read_csv(PROCESSED_DIR/'moab_features_train.csv',parse_dates=['Date'])
 test=pd.read_csv(PROCESSED_DIR/'moab_features_test.csv',parse_dates=['Date'])
 meta=json.loads((PROCESSED_DIR/'feature_metadata.json').read_text())
 outcomes=pd.read_csv(PROCESSED_DIR/'training_outcomes.csv',parse_dates=['Date'])
 assert train.Date.equals(outcomes.Date)
 for d in [train,test]:
  assert d.Date.is_unique and d.Date.is_monotonic_increasing
  assert d.Date.diff().dropna().eq(pd.Timedelta(days=1)).all()
  assert d.Elevated_Risk.isin([0,1]).all()
 assert train.Date.max()+pd.Timedelta(days=7)<=test.Date.min()
 assert list(train.columns)==['Date']+meta['features']+['Elevated_Risk']
 assert list(test.columns)==list(train.columns)
 assert len(train)==5977 and len(test)==1496 and len(meta['features'])==24
 return train,test,meta,outcomes

def folds(train,outcomes):
 output=[];cols=['Future_EventCount_7d','Future_Energy_7d']
 for fold,(tr,va) in enumerate(TimeSeriesSplit(n_splits=5,gap=6).split(train),1):
  assert train.Date.iloc[tr[-1]]+pd.Timedelta(days=7)<=train.Date.iloc[va[0]]
  thresholds=outcomes.iloc[tr][cols].quantile(.95)
  labels=(outcomes[cols]>=thresholds).any(axis=1).astype(int).to_numpy()
  assert len(np.unique(labels[tr]))==2
  output.append((fold,tr,va,labels,thresholds))
 return output

def score(y,pred,values=None):
 y=np.asarray(y);pred=np.asarray(pred);tn,fp,fn,tp=confusion_matrix(y,pred,labels=[0,1]).ravel();both=len(np.unique(y))==2
 return dict(Accuracy=accuracy_score(y,pred),Precision=precision_score(y,pred,zero_division=0),Recall=recall_score(y,pred,zero_division=0),F1=f1_score(y,pred,zero_division=0),
  Balanced_Accuracy=balanced_accuracy_score(y,pred) if both else np.nan,MCC=matthews_corrcoef(y,pred),
  ROC_AUC=roc_auc_score(y,values) if values is not None and both else np.nan,
  Average_Precision=average_precision_score(y,values) if values is not None and y.sum()>0 else np.nan,
  TN=int(tn),FP=int(fp),FN=int(fn),TP=int(tp),Positive_Count=int(y.sum()),N=len(y))

def make_model(family,config,y):
 p=dict(config)
 if family=='random_forest':return Pipeline([('imputer',SimpleImputer(strategy='median')),('model',RandomForestClassifier(n_estimators=500,random_state=42,n_jobs=1,**p))])
 if family=='xgboost':
  from xgboost import XGBClassifier
  balanced=p.pop('balanced');weight=float((np.asarray(y)==0).sum()/max((np.asarray(y)==1).sum(),1)) if balanced else 1.
  return XGBClassifier(**p,scale_pos_weight=weight,objective='binary:logistic',eval_metric='logloss',random_state=42,n_jobs=1,tree_method='hist',device='cpu',importance_type='gain')
 if family=='svm':est=SVC(**p,random_state=42)
 elif family=='mlp':
  p['hidden_layer_sizes']=tuple(p['hidden_layer_sizes'])
  est=MLPClassifier(**p,activation='relu',solver='adam',learning_rate_init=.001,batch_size=64,max_iter=2000,early_stopping=False,n_iter_no_change=15,random_state=42)
 elif family=='logistic':est=LogisticRegression(**p,max_iter=2000,random_state=42)
 else:raise ValueError(family)
 return Pipeline([('imputer',SimpleImputer(strategy='median')),('scaler',StandardScaler()),('model',est)])

def scores(model,X):return model.decision_function(X) if hasattr(model,'decision_function') else model.predict_proba(X)[:,1]

def fit_logged(model,X,y):
 with warnings.catch_warnings(record=True) as caught:
  warnings.simplefilter('always');model.fit(X,y)
 return [str(w.message) for w in caught]

def inputs():return {n:sha(PROCESSED_DIR/n) for n in ['moab_features_train.csv','moab_features_test.csv','training_outcomes.csv']}

def save_model_results(family,name,model,train,test,meta,cv,summary,warning_rows):
 dest=RESULTS_DIR/family;dest.mkdir(exist_ok=True);X=test[meta['features']];y=test.Elevated_Risk.to_numpy()
 pred=model.predict(X);value=scores(model,X)
 metrics=pd.DataFrame([{'Model':name,'Family':family,**score(y,pred,value)}]);metrics.to_csv(dest/'metrics.csv',index=False)
 pd.DataFrame({'Date':test.Date,'Actual':y,'Predicted':pred,'Score':value}).to_csv(dest/'predictions.csv',index=False)
 cv.to_csv(dest/'cv_results.csv',index=False);summary.to_csv(dest/'cv_summary.csv',index=False)
 joblib.dump(model,dest/'model.joblib')
 if family=='xgboost':model.save_model(dest/'model.json')
 est=model.named_steps['model'] if hasattr(model,'named_steps') else model
 (dest/'run.json').write_text(json.dumps({'selected_configuration':name,'parameters':model.get_params(deep=True),'environment':environment(),
 'inputs':inputs(),'validation':'five folds; gap 6; fold-local target thresholds and preprocessing','warnings':warning_rows,
 'training_iterations':getattr(est,'n_iter_',None),'test_status':'retrospective; previously inspected during development'},indent=2,default=str))
 fig,axes=plt.subplots(1,3,figsize=(15,4))
 ConfusionMatrixDisplay.from_predictions(y,pred,labels=[0,1],display_labels=['Not elevated','Elevated'],ax=axes[0],colorbar=False)
 RocCurveDisplay.from_predictions(y,value,ax=axes[1],name=name);PrecisionRecallDisplay.from_predictions(y,value,ax=axes[2],name=name)
 axes[2].axhline(y.mean(),color='grey',ls='--',label='Prevalence');axes[2].legend();fig.tight_layout();fig.savefig(dest/'diagnostics.png',dpi=160);plt.show();plt.close(fig)
 if hasattr(est,'feature_importances_'):
  w=pd.DataFrame({'Feature':meta['features'],'Importance':est.feature_importances_}).sort_values('Importance');w.to_csv(dest/'feature_importance.csv',index=False)
  ax=w.plot.barh(x='Feature',y='Importance',figsize=(8,7),legend=False);ax.set_title(name+' — fitted importance');plt.tight_layout();plt.savefig(dest/'feature_importance.png',dpi=160);plt.show();plt.close()
 if family=='svm' and est.kernel=='linear':
  w=pd.DataFrame({'Feature':meta['features'],'Standardized_Coefficient':est.coef_[0]}).sort_values('Standardized_Coefficient');w.to_csv(dest/'coefficients.csv',index=False)
  ax=w.plot.barh(x='Feature',y='Standardized_Coefficient',figsize=(8,7),legend=False);ax.set_title('SVM coefficients: conditional associations');plt.tight_layout();plt.savefig(dest/'coefficients.png',dpi=160);plt.show();plt.close()
 return metrics
